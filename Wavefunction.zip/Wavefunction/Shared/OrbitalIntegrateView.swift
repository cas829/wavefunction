//
//  OrbitalIntegrateView.swift
//  Wavefunction
//
//  Created by Whit Castiglioni on 2/22/21.
//

/////////////// //  /   /   /   //  /   //  /   /   /   //  /   //q /   /   /   //  /   /   /   /   //  /   /   /   /   /   /   /   /   /   /   //  /   /




/////////   /   /   /   //  /   /   /   /   /   /   /   /   /   /   /// /   q   /   /   //      //      //      /   /   /   /   /   //  /   /   /   /   /   /
import Foundation
import SwiftUI



struct OrbitalIntegrateView: View {
    
    var functionSelect = ["<Ψ100|Ψ100> ", "<Ψ100|Ψ210>", "<Ψ210|Ψ100>", "<Ψ210|Ψ210>"]
    @State private var selectedFunctionIndex = 0
    
    //@State var pi = 0.0
    @State var totalGuesses = 0
    @State var totalIntegral = 0.0
    @State var domainLimit = 1.0
    //@State var guessString = "15625"
  
    @State var totalGuessString = "0"
  
    @State var runsString = "15625"
    
    @State var PhiIntegralOverlap = "0.0"
    
    @State var OrbitalA_XDistance = 0.0
    @State var OrbitalA_XDistanceString = "0.0"

    @State var OrbitalB_XDistance = -0.0
    @State var OrbitalB_XDistanceString = "0.0"
    
    @State var OrbitalA_ZDistance = 1.0
    @State var OrbitalA_ZDistanceString = "1.0"

    @State var OrbitalB_ZDistance = -1.0
    @State var OrbitalB_ZDistanceString = "-1.0"

    
    var plotDataModel: PlotDataClass? = nil

    @State var maxYsliceString = "0.2"
    @State var minYsliceString = "-0.2"
    @State var maxYsliceDistance = 0.2
    @State var minYsliceDistance = -0.2
    
    
    
    // Setup the GUI to monitor the data from the Monte Carlo Integral Calculator
    //@ObservedObject var monteCarlo = OrbitalIntegrate()
    
    @ObservedObject var phiClass = OrbitalIntegrate(withData: true)

    
    //Setup the GUI View
    var body: some View {
        HStack{
            
            VStack{
                Picker(selection: $selectedFunctionIndex, label: Text("")) {
                        ForEach(0 ..< functionSelect.count) {
                           Text(self.functionSelect[$0])
                        }
                }
                     Text("Selected Function:  \(functionSelect[selectedFunctionIndex])")
                VStack(alignment: .center) {
                    Text("Runs")
                        .font(.callout)
                        .bold()
                    TextField("# Runs", text: $runsString)
                        .padding()
                }
                .padding(.top, 5.0)
                
                VStack(alignment: .center) {
                    Text("Total Guesses")
                        .font(.callout)
                        .bold()
                    TextField("# Total Guesses", text: $totalGuessString)
                        .padding()
                }
//                VStack{
//                    HStack(alignment: .center) {
//                        Text("Orbital A X distace")
//                            .font(.callout)
//                            .bold()
//                        TextField("Orbital A X distace", text: $OrbitalA_XDistanceString)
//                            .padding()
//                        Text("Orbital B X distace")
//                            .font(.callout)
//                            .bold()
//                        TextField("Orbital B X distace", text: $OrbitalB_XDistanceString)
//                            .padding()
//                    }
//
//                }
                HStack(alignment: .center){
                    Text("Orbital A Z distace")
                        .font(.callout)
                        .bold()
                    TextField("Orbital A Z distace", text: $OrbitalA_ZDistanceString)
                        .padding()
                    Text("Orbital B Z distace")
                        .font(.callout)
                        .bold()
                    TextField("Orbital B Z distace", text: $OrbitalB_ZDistanceString)
                        .padding()
                }
                HStack(alignment: .center){
                    Text("max Y slice ")
                        .font(.callout)
                        .bold()
                    TextField("Orbital A X distace", text: $maxYsliceString)
                        .padding()
                    Text("min Y slice")
                        .font(.callout)
                        .bold()
                    TextField("Orbital B X distace", text: $minYsliceString)
                        .padding()
                }
                
                VStack(alignment: .center) {
                    Text("Phi Overlap")
                        .font(.callout)
                        .bold()
                    TextField("# Phi Integral ", text: $PhiIntegralOverlap)
                        .padding()
                }
                
                Button("UNLEASH THE WAVE", action: {self.calculateIntegral() })
                    .padding()
//
                Button("Clear", action: {self.clear()})
                    .padding(.bottom, 5.0)
//
            }
            .padding()
            
            //DrawingField
            //red is neg
            //blue is pos
          
            drawingView(redLayer: $phiClass.orbitalDataNegative, blueLayer: $phiClass.orbitalDataPostive, red13Layer: $phiClass.orbitalData_13_Negative, blue13Layer: $phiClass.orbitalData_13_Postive, red12Layer: $phiClass.orbitalData_12_Negative, blue12Layer: $phiClass.orbitalData_12_Postive, red11Layer: $phiClass.orbitalData_11_Negative, blue11Layer: $phiClass.orbitalData_11_Postive, red10Layer: $phiClass.orbitalData_10_Negative, blue10Layer: $phiClass.orbitalData_10_Postive, red9Layer: $phiClass.orbitalData_9_Negative, blue9Layer: $phiClass.orbitalData_9_Postive, red8Layer: $phiClass.orbitalData_8_Negative, blue8Layer: $phiClass.orbitalData_8_Postive, red7Layer: $phiClass.orbitalData_7_Negative, blue7Layer: $phiClass.orbitalData_7_Postive, red6Layer: $phiClass.orbitalData_6_Negative, blue6Layer: $phiClass.orbitalData_6_Postive, red5Layer: $phiClass.orbitalData_5_Negative, blue5Layer: $phiClass.orbitalData_5_Postive, red4Layer: $phiClass.orbitalData_4_Negative, blue4Layer: $phiClass.orbitalData_4_Postive, red3Layer: $phiClass.orbitalData_3_Negative, blue3Layer: $phiClass.orbitalData_3_Postive, red2Layer: $phiClass.orbitalData_2_Negative, blue2Layer: $phiClass.orbitalData_2_Postive, red1Layer: $phiClass.orbitalData_1_Negative, blue1Layer: $phiClass.orbitalData_1_Postive, red0Layer: $phiClass.orbitalData_0_Negative, blue0Layer: $phiClass.orbitalData_0_Postive, xMin: $phiClass.zBoxMin, xMax: $phiClass.zBoxMax, yMin: $phiClass.zBoxMin, yMax: $phiClass.zBoxMax, zPositionA: $OrbitalA_ZDistance ,xPositionA: $OrbitalA_XDistance, zPositionB: $OrbitalB_ZDistance ,xPositionB: $OrbitalB_XDistance ,ZeroLayer: $phiClass.orbitalDataZero)
            
                .padding()
                .aspectRatio(1, contentMode: .fit)
                .drawingGroup()
            // Stop the window shrinking to zero.
           // Spacer()
        }
    }
    func calculateIntegral(){
//        OrbitalA_XDistance = Double(OrbitalA_XDistanceString) ?? Double(0.0)
//        phiClass.x_A_ParticleCartesian = OrbitalA_XDistance
//
//        OrbitalB_XDistance = Double(OrbitalB_XDistanceString) ?? Double(0.0)
//        phiClass.x_B_ParticleCartesian = OrbitalB_XDistance
//
        OrbitalA_ZDistance = Double(OrbitalA_ZDistanceString) ?? Double(0.0)
        phiClass.z_A_ParticleCartesian = OrbitalA_ZDistance
        
        OrbitalB_ZDistance = Double(OrbitalB_ZDistanceString) ?? Double(0.0)
        phiClass.z_B_ParticleCartesian = OrbitalB_ZDistance
        
        
        maxYsliceDistance = Double(maxYsliceString) ?? Double(0.0)
        phiClass.maxYslice = maxYsliceDistance
        
        minYsliceDistance = Double(minYsliceString) ?? Double(0.0)
        phiClass.minYslice = minYsliceDistance
        
        let runsToPass = Int(runsString) ?? Int(0)
        
        totalGuesses += runsToPass
        totalGuessString = String(totalGuesses)
        
        let tempFunctionIndex = selectedFunctionIndex
        switch tempFunctionIndex {
            case 0:
                phiClass.phiCalculatorCall_1s_1s(runsPassed: runsToPass)
            case 1:
                phiClass.phiCalculatorCall_1s_2pz(runsPassed: runsToPass, OrbitalA1s: true)
            case 2:
                phiClass.phiCalculatorCall_1s_2pz(runsPassed: runsToPass, OrbitalA1s: false)
            case 3:
                phiClass.phiCalculatorCall_2pz_2pz(runsPassed: runsToPass)
            default:
                phiClass.phiCalculatorCall_1s_1s(runsPassed: runsToPass)
        }
        
        //phiClass.phiCalculatorCall_1s_1s(runsPassed: runsToPass)
        
        let tempPhiHold = phiClass.phiOverlap
        PhiIntegralOverlap = "\(tempPhiHold)"
    }
    func clear(){
        runsString = "15625"
        totalGuessString = "0"

        totalGuesses = 0
        totalIntegral = 0.0
        domainLimit = 1.0
      
        runsString = "15625"
        
        PhiIntegralOverlap = "0.0"
        
        OrbitalA_XDistance = 0.0
        OrbitalA_XDistanceString = "0.0"

        OrbitalB_XDistance = 0.0
        OrbitalB_XDistanceString = "0.0"
        
        OrbitalA_ZDistance = 1.0
        OrbitalA_ZDistanceString = "1.0"

        OrbitalB_ZDistance = -1.0
        OrbitalB_ZDistanceString = "-1.0"
        
        maxYsliceString = "0.2"
        minYsliceString = "-0.2"
        maxYsliceDistance = 0.2
        minYsliceDistance = -0.2
        
        phiClass.clear()
//
        
    }
}

struct OrbitalIntegrateView_Previews: PreviewProvider {
    static var previews: some View {
        OrbitalIntegrateView()
    }
}
 
