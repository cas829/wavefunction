//
//  OrbitalIntegrate.swift
//  Wavefunction
//
//  Created by Whit Castiglioni on 2/22/21.
//
//typealias nthTermParameterTuple = (n: Int, x: Double)
//typealias nthTermMultiplierHandler = (_ parameters: [nthTermParameterTuple]) -> Double
//typealias ErrorHandler = (_ parameters: [ErrorParameterTuple]) -> Double
//typealias ErrorParameterTuple = (n: Int, x: Double, sum: Double)

//func calculate1DInfiniteSum(function: nthTermMultiplierHandler, x: Double, minimum: Int, maximum: Int, firstTerm: Double, isPlotError: Bool, errorType: ErrorHandler ) -> Double {

typealias wavefunctionParameterTuple = (xInput: Double, yInput: Double, zInput: Double, nucleusCharge: Int)
typealias wavefunctionHandler = (_ parameters: [wavefunctionParameterTuple]) -> Double



import Foundation

class OrbitalIntegrate: NSObject, ObservableObject {
    //
    @Published var x_A_ParticleCartesian = 0.0
    @Published var y_A_ParticleCartesian = 0.0
    @Published var z_A_ParticleCartesian = 1.0
    
    @Published var x_B_ParticleCartesian = 0.0
    @Published var y_B_ParticleCartesian = 0.0
    @Published var z_B_ParticleCartesian = -1.0
    
    @Published var totalRuns = 0
    
    @Published var phiSum = 0.0
    
    //max length width and hight of containing box
    @Published var xBoxMax = 10.0
    @Published var yBoxMax = 10.0
    @Published var zBoxMax = 10.0
    //min length width and hight of containing box
    @Published var xBoxMin = -10.0
    @Published var yBoxMin = -10.0
    @Published var zBoxMin = -10.0

    @Published var phiOverlap = 0.0
    
    //14
    @Published var orbitalDataPostive = [(zPoint: Double, xPoint: Double)]()
    @Published var orbitalDataNegative = [(zPoint: Double, xPoint: Double)]()
    @Published var orbitalDataZero = [(zPoint: Double, xPoint: Double)]()

    //13
    @Published var orbitalData_13_Postive = [(zPoint: Double, xPoint: Double)]()
    @Published var orbitalData_13_Negative = [(zPoint: Double, xPoint: Double)]()
    //12
    @Published var orbitalData_12_Postive = [(zPoint: Double, xPoint: Double)]()
    @Published var orbitalData_12_Negative = [(zPoint: Double, xPoint: Double)]()
    //11
    @Published var orbitalData_11_Postive = [(zPoint: Double, xPoint: Double)]()
    @Published var orbitalData_11_Negative = [(zPoint: Double, xPoint: Double)]()
    //10
    @Published var orbitalData_10_Postive = [(zPoint: Double, xPoint: Double)]()
    @Published var orbitalData_10_Negative = [(zPoint: Double, xPoint: Double)]()
    //9
    @Published var orbitalData_9_Postive = [(zPoint: Double, xPoint: Double)]()
    @Published var orbitalData_9_Negative = [(zPoint: Double, xPoint: Double)]()
    //8
    @Published var orbitalData_8_Postive = [(zPoint: Double, xPoint: Double)]()
    @Published var orbitalData_8_Negative = [(zPoint: Double, xPoint: Double)]()
    //7
    @Published var orbitalData_7_Postive = [(zPoint: Double, xPoint: Double)]()
    @Published var orbitalData_7_Negative = [(zPoint: Double, xPoint: Double)]()
    //6
    @Published var orbitalData_6_Postive = [(zPoint: Double, xPoint: Double)]()
    @Published var orbitalData_6_Negative = [(zPoint: Double, xPoint: Double)]()
    //5
    @Published var orbitalData_5_Postive = [(zPoint: Double, xPoint: Double)]()
    @Published var orbitalData_5_Negative = [(zPoint: Double, xPoint: Double)]()
    //4
    @Published var orbitalData_4_Postive = [(zPoint: Double, xPoint: Double)]()
    @Published var orbitalData_4_Negative = [(zPoint: Double, xPoint: Double)]()
    //3
    @Published var orbitalData_3_Postive = [(zPoint: Double, xPoint: Double)]()
    @Published var orbitalData_3_Negative = [(zPoint: Double, xPoint: Double)]()
    //2
    @Published var orbitalData_2_Postive = [(zPoint: Double, xPoint: Double)]()
    @Published var orbitalData_2_Negative = [(zPoint: Double, xPoint: Double)]()
    //1
    @Published var orbitalData_1_Postive = [(zPoint: Double, xPoint: Double)]()
    @Published var orbitalData_1_Negative = [(zPoint: Double, xPoint: Double)]()
    //0
    @Published var orbitalData_0_Postive = [(zPoint: Double, xPoint: Double)]()
    @Published var orbitalData_0_Negative = [(zPoint: Double, xPoint: Double)]()
    
    

    @Published var maxYslice = 0.2
    @Published var minYslice = -0.2

    
    init(withData data: Bool){
        
        super.init()
        orbitalDataPostive = []
        orbitalDataNegative = []
        
        orbitalData_13_Postive = []
        orbitalData_12_Postive = []
        orbitalData_11_Postive = []
        orbitalData_10_Postive = []
        orbitalData_9_Postive = []
        orbitalData_8_Postive = []
        orbitalData_7_Postive = []
        orbitalData_6_Postive = []
        orbitalData_5_Postive = []
        orbitalData_4_Postive = []
        orbitalData_3_Postive = []
        orbitalData_2_Postive = []
        orbitalData_1_Postive = []
        orbitalData_0_Postive = []

        orbitalData_13_Negative = []
        orbitalData_12_Negative = []
        orbitalData_11_Negative = []
        orbitalData_10_Negative = []
        orbitalData_9_Negative = []
        orbitalData_8_Negative = []
        orbitalData_7_Negative = []
        orbitalData_6_Negative = []
        orbitalData_5_Negative = []
        orbitalData_4_Negative = []
        orbitalData_3_Negative = []
        orbitalData_2_Negative = []
        orbitalData_1_Negative = []
        orbitalData_0_Negative = []

        orbitalDataZero = []
        
    }
    //runsPassed is how many random points to be generated to calculater intergrul
    func phiCalculatorCall_1s_1s(runsPassed: Int) {
        phiOverlapCalculator(function_a: orbital_1s, function_b: orbital_1s, runs: runsPassed)
    }
    //runsPassed is how many random points to be generated to calculater intergrul
    //OrbitalA1s should be marked as true if partical A is the 1s, false if be is 1s
    func phiCalculatorCall_1s_2pz(runsPassed: Int, OrbitalA1s: Bool) {
        if OrbitalA1s {
            phiOverlapCalculator(function_a: orbital_1s, function_b: orbital_2pz, runs: runsPassed)
        }
        else{
            phiOverlapCalculator(function_a: orbital_2pz, function_b: orbital_1s, runs: runsPassed)
        }
    }
    func phiCalculatorCall_2pz_2pz(runsPassed: Int) {
        phiOverlapCalculator(function_a: orbital_2pz, function_b: orbital_2pz, runs: runsPassed)
    }
    func phiOverlapCalculator(function_a: wavefunctionHandler, function_b: wavefunctionHandler, runs: Int){
        //var loopRepetitions = 0
        var phiTempSum = 0.0
        var point = (zPoint: 0.0, xPoint: 0.0)
        
        var newPointsPostive : [(zPoint: Double, xPoint: Double)] = []
        var newPointsNegative : [(zPoint: Double, xPoint: Double)] = []
        var newPointsZero : [(zPoint: Double, xPoint: Double)] = []

        var new13PointsPostive : [(zPoint: Double, xPoint: Double)] = []
        var new13PointsNegative : [(zPoint: Double, xPoint: Double)] = []
        
        var new12PointsPostive : [(zPoint: Double, xPoint: Double)] = []
        var new12PointsNegative : [(zPoint: Double, xPoint: Double)] = []
        
        var new11PointsPostive : [(zPoint: Double, xPoint: Double)] = []
        var new11PointsNegative : [(zPoint: Double, xPoint: Double)] = []
        
        var new10PointsPostive : [(zPoint: Double, xPoint: Double)] = []
        var new10PointsNegative : [(zPoint: Double, xPoint: Double)] = []
        
        var new9PointsPostive : [(zPoint: Double, xPoint: Double)] = []
        var new9PointsNegative : [(zPoint: Double, xPoint: Double)] = []
        
        var new8PointsPostive : [(zPoint: Double, xPoint: Double)] = []
        var new8PointsNegative : [(zPoint: Double, xPoint: Double)] = []
        
        var new7PointsPostive : [(zPoint: Double, xPoint: Double)] = []
        var new7PointsNegative : [(zPoint: Double, xPoint: Double)] = []
        
        var new6PointsPostive : [(zPoint: Double, xPoint: Double)] = []
        var new6PointsNegative : [(zPoint: Double, xPoint: Double)] = []
        
        var new5PointsPostive : [(zPoint: Double, xPoint: Double)] = []
        var new5PointsNegative : [(zPoint: Double, xPoint: Double)] = []
        
        var new4PointsPostive : [(zPoint: Double, xPoint: Double)] = []
        var new4PointsNegative : [(zPoint: Double, xPoint: Double)] = []
        
        var new3PointsPostive : [(zPoint: Double, xPoint: Double)] = []
        var new3PointsNegative : [(zPoint: Double, xPoint: Double)] = []
        
        var new2PointsPostive : [(zPoint: Double, xPoint: Double)] = []
        var new2PointsNegative : [(zPoint: Double, xPoint: Double)] = []
        
        var new1PointsPostive : [(zPoint: Double, xPoint: Double)] = []
        var new1PointsNegative : [(zPoint: Double, xPoint: Double)] = []
        
        var new0PointsPostive : [(zPoint: Double, xPoint: Double)] = []
        var new0PointsNegative : [(zPoint: Double, xPoint: Double)] = []
        
        
        
        let BoundingCalculator = BoundingBox()
        let volume = BoundingCalculator.calculateVolume(lengthOfSide1: (xBoxMax - xBoxMin), lengthOfSide2: (yBoxMax - yBoxMin), lengthOfSide3: (zBoxMax - zBoxMin))
        for _ in 0..<runs {
            let random_x_point = Double.random(in: xBoxMin..<xBoxMax)
            let random_y_point = Double.random(in: yBoxMin..<yBoxMax)
            let random_z_point = Double.random(in: zBoxMin..<zBoxMax)

            point.zPoint = random_z_point
            point.xPoint = random_x_point
            
            //newPointsPostive.append(point)
            
            let random_x_a_point = shiftX_A_CartesianToCartesian(xPrime: random_x_point)
            let random_y_a_point = shiftY_A_CartesianToCartesian(yPrime: random_y_point)
            let random_z_a_point = shiftZ_A_CartesianToCartesian(zPrime: random_z_point)
            
            let parameters_A: [wavefunctionParameterTuple] = [(xInput: random_x_a_point, yInput: random_y_a_point, zInput: random_z_a_point, nucleusCharge: 1)]
            let phi_a = function_a(parameters_A)


            let random_x_b_point = shiftX_B_CartesianToCartesian(xPrime: random_x_point)
            let random_y_b_point = shiftY_B_CartesianToCartesian(yPrime: random_y_point)
            let random_z_b_point = shiftZ_B_CartesianToCartesian(zPrime: random_z_point)

            let parameters_b: [wavefunctionParameterTuple] = [(xInput: random_x_b_point, yInput: random_y_b_point, zInput: random_z_b_point, nucleusCharge: 1)]
            let phi_b = function_b(parameters_b)
            
            let finalPhi = phi_a * phi_b
            
            var inSlice = false
            if random_y_point < maxYslice && random_y_point > minYslice {
                inSlice = true
            }
            //var colorIntenctySortShifted = 0.0
            let colorIntenctySortShifted = log(abs(finalPhi))
            let colorIntenctySort = colorIntenctySortShifted + 15.0
            let colorIntenctySortSwitch = floor(colorIntenctySort)
            //var colorIntenctySortSwitch = Int(colorIntenctySortSwitchTemp)

            if inSlice {
                if finalPhi < 0.0 {
                    //newPointsNegative.append(point)
                    switch colorIntenctySortSwitch {
                        case 14:
                            newPointsNegative.append(point)
                        case 13:
                            new13PointsNegative.append(point)
                        case 12:
                            new12PointsNegative.append(point)
                        case 11:
                            new11PointsNegative.append(point)
                        case 10:
                            new10PointsNegative.append(point)
                        case 9:
                            new9PointsNegative.append(point)
                        case 8:
                            new8PointsNegative.append(point)
                        case 7:
                            new7PointsNegative.append(point)
                        case 6:
                            new6PointsNegative.append(point)
                        case 5:
                            new5PointsNegative.append(point)
                        case 4:
                            new4PointsNegative.append(point)
                        case 3:
                            new3PointsNegative.append(point)
                        case 2:
                            new2PointsNegative.append(point)
                        case 1:
                            new1PointsNegative.append(point)
                        case 0:
                            new0PointsNegative.append(point)
                        default:
                            newPointsZero.append(point)
                    }
                }
                else if finalPhi > 0.0{
                    switch colorIntenctySortSwitch {
                        case 14:
                            newPointsPostive.append(point)
                        case 13:
                            new13PointsPostive.append(point)
                        case 12:
                            new12PointsPostive.append(point)
                        case 11:
                            new11PointsPostive.append(point)
                        case 10:
                            new10PointsPostive.append(point)
                        case 9:
                            new9PointsPostive.append(point)
                        case 8:
                            new8PointsPostive.append(point)
//                            let tempR1 = pow(random_x_point, 2.0) + pow(random_y_point, 2.0) + pow(random_z_point, 2.0)
//                            let tempR2 = sqrt(tempR1)
//                            let tempRString = String(tempR2)
//                            let psiA = orbital_1s(parameters: [(xInput: random_x_point, yInput: random_y_point, zInput: random_z_point, nucleusCharge: 1)])
//                            let psiB = orbital_2pz(parameters: [(xInput: random_x_point, yInput: random_y_point, zInput: random_z_point, nucleusCharge: 1)])
//                            let calpsi = psiA * psiB
//                            let solString = String(calpsi)
//
//                            print("new8PointsPostive: finalPhi=" + String(finalPhi) + "  colorIntenctySortSwitch = " + String(colorIntenctySortSwitch) + "  dis:" + tempRString)
//
//                            print(String(finalPhi) + " =?= " + solString)
                        case 7:
                            new7PointsPostive.append(point)
                        case 6:
                            new6PointsPostive.append(point)
                        case 5:
                            new5PointsPostive.append(point)
                        case 4:
                            new4PointsPostive.append(point)
                        case 3:
                            new3PointsPostive.append(point)
                        case 2:
                            new2PointsPostive.append(point)
                        case 1:
                            new1PointsPostive.append(point)
                        case 0:
                            new0PointsPostive.append(point)
                        default:
                            newPointsZero.append(point)
                    }
                }
                else{
                    newPointsZero.append(point)
                }
            }
//            if finalPhi < 0.0 {
//                newPointsNegative.append(point)
//            }
//            else if finalPhi > 0.0{
//                newPointsPostive.append(point)
//            }
//            else{
//                orbitalDataZero.append(point)
//            }
            phiTempSum += finalPhi
        }
        phiOverlap = volume * phiTempSum / Double(runs)
        totalRuns += runs
        if ((runs < 1000000001) || (orbitalDataPostive.count == 0)){
            orbitalDataPostive.append(contentsOf: newPointsPostive)
        }
        if ((runs < 1000000001) || (orbitalData_13_Postive.count == 0)){
            orbitalData_13_Postive.append(contentsOf: new13PointsPostive)
        }
        if ((runs < 1000000001) || (orbitalData_12_Postive.count == 0)){
            orbitalData_12_Postive.append(contentsOf: new12PointsPostive)
        }
        if ((runs < 1000000001) || (orbitalData_11_Postive.count == 0)){
            orbitalData_11_Postive.append(contentsOf: new11PointsPostive)
        }
        if ((runs < 1000000001) || (orbitalData_10_Postive.count == 0)){
            orbitalData_10_Postive.append(contentsOf: new10PointsPostive)
        }
        if ((runs < 1000000001) || (orbitalData_9_Postive.count == 0)){
            orbitalData_9_Postive.append(contentsOf: new9PointsPostive)
        }
        if ((runs < 1000000001) || (orbitalData_8_Postive.count == 0)){
            orbitalData_8_Postive.append(contentsOf: new8PointsPostive)
        }
        if ((runs < 1000000001) || (orbitalData_7_Postive.count == 0)){
            orbitalData_7_Postive.append(contentsOf: new7PointsPostive)
        }
        if ((runs < 1000000001) || (orbitalData_6_Postive.count == 0)){
            orbitalData_6_Postive.append(contentsOf: new6PointsPostive)
        }
        if ((runs < 1000000001) || (orbitalData_5_Postive.count == 0)){
            orbitalData_5_Postive.append(contentsOf: new5PointsPostive)
        }
        if ((runs < 1000000001) || (orbitalData_4_Postive.count == 0)){
            orbitalData_4_Postive.append(contentsOf: new4PointsPostive)
        }
        if ((runs < 1000000001) || (orbitalData_3_Postive.count == 0)){
            orbitalData_3_Postive.append(contentsOf: new3PointsPostive)
        }
        if ((runs < 1000000001) || (orbitalData_2_Postive.count == 0)){
            orbitalData_2_Postive.append(contentsOf: new2PointsPostive)
        }
        if ((runs < 1000000001) || (orbitalData_1_Postive.count == 0)){
            orbitalData_1_Postive.append(contentsOf: new1PointsPostive)
        }
        if ((runs < 1000000001) || (orbitalData_0_Postive.count == 0)){
            orbitalData_0_Postive.append(contentsOf: new0PointsPostive)
        }
        
        if ((runs < 1000000001) || (newPointsNegative.count == 0)){
            orbitalDataNegative.append(contentsOf: newPointsNegative)
        }
        if ((runs < 1000000001) || (orbitalData_13_Negative.count == 0)){
            orbitalData_13_Negative.append(contentsOf: new13PointsNegative)
        }
        if ((runs < 1000000001) || (orbitalData_12_Negative.count == 0)){
            orbitalData_12_Negative.append(contentsOf: new12PointsNegative)
        }
        if ((runs < 1000000001) || (orbitalData_11_Negative.count == 0)){
            orbitalData_11_Negative.append(contentsOf: new11PointsNegative)
        }
        if ((runs < 1000000001) || (orbitalData_10_Negative.count == 0)){
            orbitalData_10_Negative.append(contentsOf: new10PointsNegative)
        }
        if ((runs < 1000000001) || (orbitalData_9_Negative.count == 0)){
            orbitalData_9_Negative.append(contentsOf: new9PointsNegative)
        }
        if ((runs < 1000000001) || (orbitalData_8_Negative.count == 0)){
            orbitalData_8_Negative.append(contentsOf: new8PointsNegative)
        }
        if ((runs < 1000000001) || (orbitalData_7_Negative.count == 0)){
            orbitalData_7_Negative.append(contentsOf: new7PointsNegative)
        }
        if ((runs < 1000000001) || (orbitalData_6_Negative.count == 0)){
            orbitalData_6_Negative.append(contentsOf: new6PointsNegative)
        }
        if ((runs < 1000000001) || (orbitalData_5_Negative.count == 0)){
            orbitalData_5_Negative.append(contentsOf: new5PointsNegative)
        }
        if ((runs < 1000000001) || (orbitalData_4_Negative.count == 0)){
            orbitalData_4_Negative.append(contentsOf: new4PointsNegative)
        }
        if ((runs < 1000000001) || (orbitalData_3_Negative.count == 0)){
            orbitalData_3_Negative.append(contentsOf: new3PointsNegative)
        }
        if ((runs < 1000000001) || (orbitalData_2_Negative.count == 0)){
            orbitalData_2_Negative.append(contentsOf: new2PointsNegative)
        }
        if ((runs < 1000000001) || (orbitalData_1_Negative.count == 0)){
            orbitalData_1_Negative.append(contentsOf: new1PointsNegative)
        }
        if ((runs < 1000000001) || (orbitalData_0_Negative.count == 0)){
            orbitalData_0_Negative.append(contentsOf: new0PointsNegative)
        }
        if ((runs < 1000000001) || (orbitalDataZero.count == 0)){
            orbitalDataZero.append(contentsOf: newPointsZero)
        }
    }
    
    
    //this function returns the value of the wavefunction of thw 1s hydrogen orbital
    //   \|/        1                   -(zr/a  )
    //    |      =  -- (z/(a ))^(3/2)  e      º
    //    |        squt(π)  º
    //      100
    //nucleusCharge/ atomic number of the nuclus
    //xInput, yInput, and zInput are all inputs in angstroms
    func orbital_1s(parameters: [wavefunctionParameterTuple])-> Double {
        let bohrRadius = 0.52917721090380
        let charge = Double(parameters[0].nucleusCharge)
        let atomicNumber = Double(charge)
        let xInput = parameters[0].xInput
        let yInput = parameters[0].yInput
        let zInput = parameters[0].zInput
        let rSuared = pow(xInput, 2.0) + pow(yInput, 2.0) + pow(zInput, 2.0)
        let radius = sqrt( rSuared )
        let rohNumerator = atomicNumber * radius
        let roh = rohNumerator / bohrRadius
        let base = (charge / bohrRadius)
        let part1of2ForPsi = pow(base, (3.0 / 2.0))
        let part2of2ForPsi = exp((-1.0 * roh))
        let Phi = part1of2ForPsi * part2of2ForPsi / sqrt(Double.pi)
        return Phi
    }
    
    //this function returns the value of the wavefunction of thw 1s hydrogen orbital
    //   \|/        1                        -(p/2  )
    //    |      =  ------ (z/(a ))^(3/2)p  e      º  cos(ø)
    //    |        squt(32π)    º
    //      210
    //nucleusCharge/ atomic number of the nuclus
    //xInput, yInput, and zInput are all inputs in angstroms
    func orbital_2pz(parameters: [wavefunctionParameterTuple])-> Double {
        let bohrRadius = 0.52917721090380
        //print(parameters[0].nucleusCharge)
        let charge = Double(parameters[0].nucleusCharge)
        //print(charge)
        let atomicNumber = Double(charge)
        let xInput = parameters[0].xInput
        let yInput = parameters[0].yInput
        let zInput = parameters[0].zInput
        let rSuared = pow(xInput, 2.0) + pow(yInput, 2.0) + pow(zInput, 2.0)
        let radius = sqrt( rSuared )
        let rohNumerator = atomicNumber * radius
        let roh = rohNumerator / bohrRadius
        let base = (charge / bohrRadius)
        let part1of3ForPsi = pow(base, (3.0 / 2.0))
        let part2of3ForPsi = exp((-1.0 * roh / 2.0))
        let cosOfPolorAngle = zInput / radius
        let part3of3ForPsi = cosOfPolorAngle * roh
        let Phi = part1of3ForPsi * part2of3ForPsi * part3of3ForPsi / sqrt(32.0 * Double.pi)
        return Phi
    }
    
    func shiftX_A_CartesianToCartesian(xPrime: Double)->Double {
        let xOriginal = x_A_ParticleCartesian
        let xShift = xPrime - xOriginal
        return xShift
    }
    func shiftY_A_CartesianToCartesian(yPrime: Double)->Double {
        let yOriginal = y_A_ParticleCartesian
        let yShift = yPrime - yOriginal
        return yShift
    }
    func shiftZ_A_CartesianToCartesian(zPrime: Double)->Double {
        let zOriginal = z_A_ParticleCartesian
        let zShift = zPrime - zOriginal
        return zShift
    }
    func shiftX_B_CartesianToCartesian(xPrime: Double)->Double {
        let xOriginal = x_B_ParticleCartesian
        let xShift = xPrime - xOriginal
        return xShift
    }
    func shiftY_B_CartesianToCartesian(yPrime: Double)->Double {
        let yOriginal = y_B_ParticleCartesian
        let yShift = yPrime - yOriginal
        return yShift
    }
    func shiftZ_B_CartesianToCartesian(zPrime: Double)->Double {
        let zOriginal = z_B_ParticleCartesian
        let zShift = zPrime - zOriginal
        return zShift
    }
    
    func clear() {
        x_A_ParticleCartesian = 0.0
        y_A_ParticleCartesian = 0.0
        z_A_ParticleCartesian = 1.0
        
        x_B_ParticleCartesian = 0.0
        y_B_ParticleCartesian = 0.0
        z_B_ParticleCartesian = -1.0
        
        totalRuns = 0
        
        phiSum = 0.0
        xBoxMax = 5.0
        yBoxMax = 5.0
        zBoxMax = 5.0
        
        xBoxMin = -5.0
        yBoxMin = -5.0
        zBoxMin = -5.0

        phiOverlap = 0.0
        
        orbitalDataPostive = []
        orbitalDataNegative = []

        
        orbitalData_13_Postive = []
        orbitalData_12_Postive = []
        orbitalData_11_Postive = []
        orbitalData_10_Postive = []
        orbitalData_9_Postive = []
        orbitalData_8_Postive = []
        orbitalData_7_Postive = []
        orbitalData_6_Postive = []
        orbitalData_5_Postive = []
        orbitalData_4_Postive = []
        orbitalData_3_Postive = []
        orbitalData_2_Postive = []
        orbitalData_1_Postive = []
        orbitalData_0_Postive = []

        orbitalData_13_Negative = []
        orbitalData_12_Negative = []
        orbitalData_11_Negative = []
        orbitalData_10_Negative = []
        orbitalData_9_Negative = []
        orbitalData_8_Negative = []
        orbitalData_7_Negative = []
        orbitalData_6_Negative = []
        orbitalData_5_Negative = []
        orbitalData_4_Negative = []
        orbitalData_3_Negative = []
        orbitalData_2_Negative = []
        orbitalData_1_Negative = []
        orbitalData_0_Negative = []

        orbitalDataZero = []
    }

    
    
    //Legycy function to be terminated once implemented out
    func shift_A_CartesianToCartesian(xPrime: Double, yPrime: Double, zPrime: Double) {
        let xOriginal = x_A_ParticleCartesian
        let yOriginal = y_A_ParticleCartesian
        let zOriginal = z_A_ParticleCartesian

        let xShift = xOriginal - xPrime
        let yShift = yOriginal - yPrime
        let zShift = zOriginal - zPrime

        x_A_ParticleCartesian = xShift
        y_A_ParticleCartesian = yShift
        z_A_ParticleCartesian = zShift
    }

}
