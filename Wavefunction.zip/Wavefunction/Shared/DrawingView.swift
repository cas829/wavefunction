//
//  DrawingView.swift
//  Monte Carlo Integration
//
//  Created by Jeff Terry on 12/31/20.
//

import SwiftUI


struct drawingView: View {
    
    // positive overlap values are blue and negitive are red
    // points reprecnt places where guesses/ calculations take place
    @Binding var redLayer : [(zPoint: Double, xPoint: Double)]
    @Binding var blueLayer : [(zPoint: Double, xPoint: Double)]
    
    @Binding var red13Layer : [(zPoint: Double, xPoint: Double)]
    @Binding var blue13Layer : [(zPoint: Double, xPoint: Double)]
    @Binding var red12Layer : [(zPoint: Double, xPoint: Double)]
    @Binding var blue12Layer : [(zPoint: Double, xPoint: Double)]
    @Binding var red11Layer : [(zPoint: Double, xPoint: Double)]
    @Binding var blue11Layer : [(zPoint: Double, xPoint: Double)]
    @Binding var red10Layer : [(zPoint: Double, xPoint: Double)]
    @Binding var blue10Layer : [(zPoint: Double, xPoint: Double)]
    @Binding var red9Layer : [(zPoint: Double, xPoint: Double)]
    @Binding var blue9Layer : [(zPoint: Double, xPoint: Double)]
    @Binding var red8Layer : [(zPoint: Double, xPoint: Double)]
    @Binding var blue8Layer : [(zPoint: Double, xPoint: Double)]
    @Binding var red7Layer : [(zPoint: Double, xPoint: Double)]
    @Binding var blue7Layer : [(zPoint: Double, xPoint: Double)]
    @Binding var red6Layer : [(zPoint: Double, xPoint: Double)]
    @Binding var blue6Layer : [(zPoint: Double, xPoint: Double)]
    @Binding var red5Layer : [(zPoint: Double, xPoint: Double)]
    @Binding var blue5Layer : [(zPoint: Double, xPoint: Double)]
    @Binding var red4Layer : [(zPoint: Double, xPoint: Double)]
    @Binding var blue4Layer : [(zPoint: Double, xPoint: Double)]
    @Binding var red3Layer : [(zPoint: Double, xPoint: Double)]
    @Binding var blue3Layer : [(zPoint: Double, xPoint: Double)]
    @Binding var red2Layer : [(zPoint: Double, xPoint: Double)]
    @Binding var blue2Layer : [(zPoint: Double, xPoint: Double)]
    @Binding var red1Layer : [(zPoint: Double, xPoint: Double)]
    @Binding var blue1Layer : [(zPoint: Double, xPoint: Double)]
    @Binding var red0Layer : [(zPoint: Double, xPoint: Double)]
    @Binding var blue0Layer : [(zPoint: Double, xPoint: Double)]

    //size of the box
    @Binding var xMin: Double
    @Binding var xMax: Double
    @Binding var yMin: Double
    @Binding var yMax: Double

    //coorodinates of the A obital cneter in z or x
    @Binding var zPositionA: Double
    @Binding var xPositionA: Double

    @Binding var zPositionB: Double
    @Binding var xPositionB: Double

    
    @Binding var ZeroLayer : [(zPoint: Double, xPoint: Double)]

    var body: some View {
    
        
        ZStack{
            drawAxis(xMin: xMin, xMax: xMax, yMin: yMin, yMax: yMax, ZonXAxis_A: zPositionA, XonYAxis_A: xPositionA, ZonXAxis_B: zPositionB, XonYAxis_B: xPositionB)
                .stroke(Color.black)
            Group{
                drawIntegral(drawingPoints: redLayer, xMin: xMin , xMax: xMax , yMin: yMin, yMax: yMax )
                    .stroke(Color.init(red: 1.0, green: 0.0, blue: 0.0))
                
                drawIntegral(drawingPoints: blueLayer, xMin: xMin, xMax: xMax , yMin: yMin, yMax: yMax  )
                    .stroke(Color.init(red: 0.0, green: 0.0, blue: 1.0))
                

                drawIntegral(drawingPoints: red13Layer, xMin: xMin , xMax: xMax , yMin: yMin, yMax: yMax )
                    .stroke(Color.init(red: 0.95, green: 0.0, blue: 0.0))

                drawIntegral(drawingPoints: blue13Layer, xMin: xMin, xMax: xMax , yMin: yMin, yMax: yMax  )
                    .stroke(Color.init(red: 0.0, green: 0.0, blue: 0.95))


                drawIntegral(drawingPoints: red12Layer, xMin: xMin , xMax: xMax , yMin: yMin, yMax: yMax )
                    .stroke(Color.init(red: 0.9, green: 0.0, blue: 0.0))
                drawIntegral(drawingPoints: blue12Layer, xMin: xMin, xMax: xMax , yMin: yMin, yMax: yMax  )
                    .stroke(Color.init(red: 0.0, green: 0.0, blue: 0.9))


                drawIntegral(drawingPoints: red11Layer, xMin: xMin , xMax: xMax , yMin: yMin, yMax: yMax )
                    .stroke(Color.init(red: 0.85, green: 0.0, blue: 0.0))
                drawIntegral(drawingPoints: blue11Layer, xMin: xMin, xMax: xMax , yMin: yMin, yMax: yMax  )
                    .stroke(Color.init(red: 0.0, green: 0.0, blue: 0.85))


                drawIntegral(drawingPoints: red10Layer, xMin: xMin , xMax: xMax , yMin: yMin, yMax: yMax )
                    .stroke(Color.init(red: 0.80, green: 0.0, blue: 0.0))
                drawIntegral(drawingPoints: blue10Layer, xMin: xMin, xMax: xMax , yMin: yMin, yMax: yMax  )
                    .stroke(Color.init(red: 0.0, green: 0.0, blue: 0.80))
            }
            Group{
                drawIntegral(drawingPoints: red9Layer, xMin: xMin , xMax: xMax , yMin: yMin, yMax: yMax )
                    .stroke(Color.init(red: 0.75, green: 0.0, blue: 0.0))
                drawIntegral(drawingPoints: blue9Layer, xMin: xMin, xMax: xMax , yMin: yMin, yMax: yMax  )
                    .stroke(Color.init(red: 0.0, green: 0.0, blue: 0.75))
                drawIntegral(drawingPoints: red8Layer, xMin: xMin , xMax: xMax , yMin: yMin, yMax: yMax )
                    .stroke(Color.init(red: 0.7, green: 0.0, blue: 0.0))
                drawIntegral(drawingPoints: blue8Layer, xMin: xMin, xMax: xMax , yMin: yMin, yMax: yMax  )
                    .stroke(Color.init(red: 0.0, green: 0.0, blue: 0.7))
                drawIntegral(drawingPoints: red7Layer, xMin: xMin , xMax: xMax , yMin: yMin, yMax: yMax )
                    .stroke(Color.init(red: 0.65, green: 0.0, blue: 0.0))
                drawIntegral(drawingPoints: blue7Layer, xMin: xMin, xMax: xMax , yMin: yMin, yMax: yMax  )
                    .stroke(Color.init(red: 0.0, green: 0.0, blue: 0.65))
                
                drawIntegral(drawingPoints: red6Layer, xMin: xMin , xMax: xMax , yMin: yMin, yMax: yMax )
                    .stroke(Color.init(red: 0.6, green: 0.0, blue: 0.0))
                drawIntegral(drawingPoints: blue6Layer, xMin: xMin, xMax: xMax , yMin: yMin, yMax: yMax  )
                    .stroke(Color.init(red: 0.0, green: 0.0, blue: 0.6))
                
                drawIntegral(drawingPoints: red5Layer, xMin: xMin , xMax: xMax , yMin: yMin, yMax: yMax )
                    .stroke(Color.init(red: 0.55, green: 0.0, blue: 0.0))
                drawIntegral(drawingPoints: blue5Layer, xMin: xMin, xMax: xMax , yMin: yMin, yMax: yMax  )
                    .stroke(Color.init(red: 0.0, green: 0.0, blue: 0.55))
                
            }
            Group{
                drawIntegral(drawingPoints: red4Layer, xMin: xMin , xMax: xMax , yMin: yMin, yMax: yMax )
                    .stroke(Color.init(red: 0.5, green: 0.0, blue: 0.0))
                drawIntegral(drawingPoints: blue4Layer, xMin: xMin, xMax: xMax , yMin: yMin, yMax: yMax  )
                    .stroke(Color.init(red: 0.0, green: 0.0, blue: 0.5))
                drawIntegral(drawingPoints: red3Layer, xMin: xMin , xMax: xMax , yMin: yMin, yMax: yMax )
                    .stroke(Color.init(red: 0.45, green: 0.0, blue: 0.0))
                drawIntegral(drawingPoints: blue3Layer, xMin: xMin, xMax: xMax , yMin: yMin, yMax: yMax  )
                    .stroke(Color.init(red: 0.0, green: 0.0, blue: 0.45))
                drawIntegral(drawingPoints: red2Layer, xMin: xMin , xMax: xMax , yMin: yMin, yMax: yMax )
                    .stroke(Color.init(red: 0.4, green: 0.0, blue: 0.0))
                drawIntegral(drawingPoints: blue2Layer, xMin: xMin, xMax: xMax , yMin: yMin, yMax: yMax  )
                    .stroke(Color.init(red: 0.0, green: 0.0, blue: 0.4))
                
                drawIntegral(drawingPoints: red1Layer, xMin: xMin , xMax: xMax , yMin: yMin, yMax: yMax )
                    .stroke(Color.init(red: 0.35, green: 0.0, blue: 0.0))
                drawIntegral(drawingPoints: blue1Layer, xMin: xMin, xMax: xMax , yMin: yMin, yMax: yMax  )
                    .stroke(Color.init(red: 0.0, green: 0.0, blue: 0.35))
                
                drawIntegral(drawingPoints: red0Layer, xMin: xMin , xMax: xMax , yMin: yMin, yMax: yMax )
                    .stroke(Color.init(red: 0.3, green: 0.0, blue: 0.0))
                drawIntegral(drawingPoints: blue0Layer, xMin: xMin, xMax: xMax , yMin: yMin, yMax: yMax  )
                    .stroke(Color.init(red: 0.0, green: 0.0, blue: 0.3))
                
            }
            drawIntegral(drawingPoints: ZeroLayer, xMin: xMin , xMax: xMax , yMin: yMin, yMax: yMax )
                .stroke(Color.black)
        }
//        ZStack{
//            drawIntegral(drawingPoints: red9Layer, xMin: xMin , xMax: xMax , yMin: yMin, yMax: yMax )
//                .stroke(Color.init(red: 0.75, green: 0.0, blue: 0.0))
//            drawIntegral(drawingPoints: blue9Layer, xMin: xMin, xMax: xMax , yMin: yMin, yMax: yMax  )
//                .stroke(Color.init(red: 0.0, green: 0.0, blue: 0.75))

//
//            drawIntegral(drawingPoints: red8Layer, xMin: xMin , xMax: xMax , yMin: yMin, yMax: yMax )
//                .stroke(Color.init(red: 0.7, green: 0.0, blue: 0.0))
//            drawIntegral(drawingPoints: blue8Layer, xMin: xMin, xMax: xMax , yMin: yMin, yMax: yMax  )
//                .stroke(Color.init(red: 0.0, green: 0.0, blue: 0.7))
//
//
//            drawIntegral(drawingPoints: red7Layer, xMin: xMin , xMax: xMax , yMin: yMin, yMax: yMax )
//                .stroke(Color.init(red: 0.65, green: 0.0, blue: 0.0))
//            drawIntegral(drawingPoints: blue7Layer, xMin: xMin, xMax: xMax , yMin: yMin, yMax: yMax  )
//                .stroke(Color.init(red: 0.0, green: 0.0, blue: 0.65))
//
//
//            drawIntegral(drawingPoints: red6Layer, xMin: xMin , xMax: xMax , yMin: yMin, yMax: yMax )
//                .stroke(Color.init(red: 0.6, green: 0.0, blue: 0.0))
//            drawIntegral(drawingPoints: blue6Layer, xMin: xMin, xMax: xMax , yMin: yMin, yMax: yMax  )
//                .stroke(Color.init(red: 0.0, green: 0.0, blue: 0.6))
            
            
            
       // }
        .background(Color.white)
        .aspectRatio(1, contentMode: .fill)
        
    }
}





struct drawIntegral: Shape {

   
    let smoothness : CGFloat = 1.0
    var drawingPoints: [(zPoint: Double, xPoint: Double)]  ///Array of tuples
    
   
    //var orientedDrawingPoints: [(xPoint: Double, yPoint: Double)]
    var xMin: Double
    var xMax: Double
    var yMin: Double
    var yMax: Double
    

     
    func path(in rect: CGRect) -> Path {
        
               
        // draw from the center of our rectangle
//        let center = CGPoint(x: rect.width / 2, y: rect.height / 2)
//        let scale = rect.width/2
        

        // Create the Path for the display
        
        var path = Path()
        
        for item in drawingPoints {
            //item.xPoint.
            //path.addRect(CGRect(x: item.xPoint*Double(scale)+Double(center.x), y: -1.0 * item.yPoint*Double(scale)+Double(center.y), width: 1.0 , height: 1.0))
           let xNumeratror = ( item.zPoint - xMin ) * Double( rect.width )
           let xDennomerator = ( xMax - xMin )
           let xAns = xNumeratror / xDennomerator
            
           let yTerm1 = Double(rect.height)
            let yT2Numerator = -1.0 * ( Double(rect.height)  ) * ( item.xPoint - yMin )
            let yT2Dennomerator = ( yMax - yMin )
           let yTerm2 = yT2Numerator / yT2Dennomerator
            let yAns = yTerm1 + yTerm2
            
            path.addRect(CGRect(x: xAns , y: yAns , width: 1.0 , height: 1.0))

        }


        return (path)
    }
}
struct drawAxis: Shape {

    let smoothness : CGFloat = 1.0

    
    
    //var orientedDrawingPoints: [(xPoint: Double, yPoint: Double)]
    var xMin: Double
    var xMax: Double
    var yMin: Double
    var yMax: Double
    
    //this wired naming is becaus the Z-axis is placed where colloquially the x-axis is(the horizaontal axis)
    var ZonXAxis_A: Double
    //this wired naming is becaus the X-axis is placed where colloquially the Y-axis is(the verical axis)
    var XonYAxis_A: Double
    var ZonXAxis_B: Double
    var XonYAxis_B: Double
    
    func path(in rect: CGRect) -> Path {
 
        
        var xNumeratror = ( ZonXAxis_A - xMin ) * Double( rect.width )
        var xDennomerator = ( xMax - xMin )
        let xAnsA = xNumeratror / xDennomerator
         
        var yTerm1 = Double(rect.height)
        var yT2Numerator = -1.0 * ( Double(rect.height)  ) * ( XonYAxis_A - yMin )
        var yT2Dennomerator = ( yMax - yMin )
        var yTerm2 = yT2Numerator / yT2Dennomerator
        let yAnsA = yTerm1 + yTerm2
        

        
        var path = Path()
        path.move(to: CGPoint(x: xAnsA , y: yAnsA ))
        
        xNumeratror = ( ZonXAxis_B - xMin ) * Double( rect.width )
        xDennomerator = ( xMax - xMin )
        let xAnsB = xNumeratror / xDennomerator
         
        yTerm1 = Double(rect.height)
        yT2Numerator = -1.0 * ( Double(rect.height)  ) * ( XonYAxis_B - yMin )
        yT2Dennomerator = ( yMax - yMin )
        yTerm2 = yT2Numerator / yT2Dennomerator
        let yAnsB = yTerm1 + yTerm2
        
        
        path.addLine(to: CGPoint(x: xAnsB , y: yAnsB ))
        return (path)
    }
}

//struct pointConvert
