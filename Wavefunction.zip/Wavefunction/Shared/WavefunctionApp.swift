//
//  WavefunctionApp.swift
//  Shared
//
//  Created by Whit Castiglioni on 2/22/21.
//

import SwiftUI

@main
struct WavefunctionApp: App {
    
    @StateObject var plotDataModel = PlotDataClass(fromLine: true)
    
    var body: some Scene {
        WindowGroup {
            TabView {
                OrbitalIntegrateView()
                    .tabItem {
                        Text("Phi Overlap calculator")
                    }
                ContentView()
                    .environmentObject(plotDataModel)
                    .tabItem {
                        Text("Plot")
                    }
                TextView()
                    .environmentObject(plotDataModel)
                    .tabItem {
                        Text("Text")
                    }
                            
                            
            }
            
        }
    }
}
