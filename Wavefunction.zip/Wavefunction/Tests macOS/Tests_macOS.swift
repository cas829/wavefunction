//
//  Tests_macOS.swift
//  Tests macOS
//
//  Created by Whit Castiglioni on 2/22/21.
//

import XCTest

class Tests_macOS: XCTestCase {

    override func setUpWithError() throws {
        // Put setup code here. This method is called before the invocation of each test method in the class.

        // In UI tests it is usually best to stop immediately when a failure occurs.
        continueAfterFailure = false

        // In UI tests it’s important to set the initial state - such as interface orientation - required for your tests before they run. The setUp method is a good place to do this.
    }

    override func tearDownWithError() throws {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
    }

    func testExample() throws {
        // UI tests must launch the application that they test.
        let my1sOrbital = OrbitalIntegrate(withData: true)
        var paramerters1s = (xInput: 0.0, yInput: 0.0, zInput: 0.0, nucleusCharge: 1)
        
        let bohrRadius = 0.52917721090380
        //print(parameters[0].nucleusCharge)
        //print(charge)

        var xInput = 0.0
        var yInput = 0.0
        var zInput = 0.0
        var rSuared = pow(xInput, 2.0) + pow(yInput, 2.0) + pow(zInput, 2.0)
        var radius = sqrt( rSuared )
        var rohNumerator =   radius
        var roh = rohNumerator / bohrRadius
        var base = ( 1.0 / bohrRadius)
        var part1of2ForPsi = pow(base, (3.0 / 2.0))
        var part2of2ForPsi = exp((-1.0 * roh))
        var Phi = part1of2ForPsi * part2of2ForPsi / sqrt(Double.pi)
        
        var orbitalvalue = my1sOrbital.orbital_1s(parameters: [paramerters1s])
        XCTAssertEqual(orbitalvalue, Phi , accuracy: 1E-12)
         xInput = 1.0
         yInput = 1.0
         zInput = 1.0
         //rSuared = pow(xInput, 2.0) + pow(yInput, 2.0) + pow(zInput, 2.0)
         rSuared = 3.0
         radius = sqrt( rSuared )
         rohNumerator =   radius
         roh = rohNumerator / bohrRadius
         base = ( 1.0 / bohrRadius)
         part1of2ForPsi = pow(base, (3.0 / 2.0))
         part2of2ForPsi = exp((-1.0 * roh))
         Phi = part1of2ForPsi * part2of2ForPsi / sqrt(Double.pi)
        
        
         paramerters1s = (xInput: 1.0, yInput: 1.0, zInput: 1.0, nucleusCharge: 1)

         orbitalvalue = my1sOrbital.orbital_1s(parameters: [paramerters1s])
        XCTAssertEqual(orbitalvalue, Phi , accuracy: 1E-12)
        
        xInput = 1.00
        yInput = 0.00
        zInput = 0.0000
        //rSuared = pow(xInput, 2.0) + pow(yInput, 2.0) + pow(zInput, 2.0)
        rSuared = 1.0
        radius = sqrt( rSuared )
        rohNumerator =   radius
        roh = rohNumerator / bohrRadius
        base = ( 1.0 / bohrRadius)
        part1of2ForPsi = pow(base, (3.0 / 2.0))
        part2of2ForPsi = exp((-1.0 * roh))
        Phi = part1of2ForPsi * part2of2ForPsi / sqrt(Double.pi)
       
       
        paramerters1s = (xInput: 1.0, yInput: 0.0, zInput: 0.0, nucleusCharge: 1)

        orbitalvalue = my1sOrbital.orbital_1s(parameters: [paramerters1s])
       XCTAssertEqual(orbitalvalue, Phi , accuracy: 1E-12)
        
        xInput = 0.00
        yInput = 1.00
        zInput = 0.0000
        rSuared = pow(xInput, 2.0) + pow(yInput, 2.0) + pow(zInput, 2.0)
        radius = sqrt( rSuared )
        rohNumerator =   radius
        roh = rohNumerator / bohrRadius
        base = ( 1.0 / bohrRadius)
        part1of2ForPsi = pow(base, (3.0 / 2.0))
        part2of2ForPsi = exp((-1.0 * roh))
        Phi = part1of2ForPsi * part2of2ForPsi / sqrt(Double.pi)
       
       
        paramerters1s = (xInput: 0.0, yInput: 1.0, zInput: 0.0, nucleusCharge: 1)

        orbitalvalue = my1sOrbital.orbital_1s(parameters: [paramerters1s])
       XCTAssertEqual(orbitalvalue, Phi , accuracy: 1E-12)
        
        
        xInput = 0.00
        yInput = 0.00
        zInput = 5.0000
        rSuared = pow(xInput, 2.0) + pow(yInput, 2.0) + pow(zInput, 2.0)
        radius = sqrt( rSuared )
        rohNumerator =   radius
        roh = rohNumerator / bohrRadius
        base = ( 1.0 / bohrRadius)
        part1of2ForPsi = pow(base, (3.0 / 2.0))
        part2of2ForPsi = exp((-1.0 * roh))
        Phi = part1of2ForPsi * part2of2ForPsi / sqrt(Double.pi)
        var PsiSquared = Phi * Phi
       
        paramerters1s = (xInput: 0.0, yInput: 0.0, zInput: 5.0, nucleusCharge: 1)

        orbitalvalue = my1sOrbital.orbital_1s(parameters: [paramerters1s])
        var orbitalvalueS = orbitalvalue * orbitalvalue
       XCTAssertEqual(orbitalvalueS, PsiSquared , accuracy: 1E-12)
        
        

        

        
        xInput = 0.00
        yInput = 0.00
        zInput = 5.0000
        rSuared = pow(xInput, 2.0) + pow(yInput, 2.0) + pow(zInput, 2.0)
        radius = sqrt( rSuared )
        rohNumerator =   radius
        roh = rohNumerator / bohrRadius
        base = ( 1.0 / bohrRadius)
        part1of2ForPsi = pow(base, (3.0 / 2.0))
        part2of2ForPsi = exp((-1.0 * roh / 2.0 ))
        let cosOfPolorAngle = zInput / radius
        let phiAngle = cosOfPolorAngle * roh
        Phi = phiAngle * part1of2ForPsi * part2of2ForPsi / sqrt(32.0 * Double.pi)
        PsiSquared = Phi * Phi

    
        paramerters1s = (xInput: 0.0, yInput: 0.0, zInput: 5.0, nucleusCharge: 1)

        orbitalvalue = my1sOrbital.orbital_2pz(parameters: [paramerters1s])
        orbitalvalueS = orbitalvalue * orbitalvalue
       XCTAssertEqual(orbitalvalueS, PsiSquared , accuracy: 1E-12)
        // Use recording to get started writing UI tests.
        // Use XCTAssert and related functions to verify your tests produce the correct results.
    }

//    func testLaunchPerformance() throws {
//        if #available(macOS 10.15, iOS 13.0, tvOS 13.0, *) {
//            // This measures how long it takes to launch your application.
//            measure(metrics: [XCTApplicationLaunchMetric()]) {
//                XCUIApplication().launch()
//            }
//        }
//    }
}
